<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'act25');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', 'root');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '&tTYN*OTvDT2(4T7Q]DQgpLXP?h?D]mc`r<Yc^?klkP/me/}k<&n@e6hlbCA-){T');
define('SECURE_AUTH_KEY',  'kTKHp4BA:aomB#!~IA8f[,)D~aEOm+PY6c 15d1oC2X*[5%5QmgA?6IUwP,coX@Y');
define('LOGGED_IN_KEY',    'INxl%dI%XbOD3Burv,}XQFR4(j{}{F([YZ&a%cxDN@dfrXh88:G z(GnC#~5BjJ9');
define('NONCE_KEY',        'hS7R0S%IR~S{-Y](hWwJ/Z; I=E@dULU]r*eEzGZcYzdd@2?ExZ2;C!G|`I+4P~K');
define('AUTH_SALT',        'B&~hWU8lT<C y+}]js!|_/wuqZ@Mpg|)x@t%q1BM*Ll-hTAfmV>dWl<T-fW]riAf');
define('SECURE_AUTH_SALT', 'qHw}Jj}sH^S[t# Pu+>cLW[8~S5`w%8CQ~K;qHM=,-gT!O41T6viCBB4o2C)USc9');
define('LOGGED_IN_SALT',   'EE1f|`c/~PD4OqZOC! JM1xLMu}EZm{?1}:,J; @~3eo<0u<2C_ZX4,mQ>`,ZBg<');
define('NONCE_SALT',       'psZx)Q;nSdHktlp,MhVi:]Aha&a#IXZF%Zu!,CGvfH$/%edlmSp_2:{i]kKePgA6');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'dl_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
